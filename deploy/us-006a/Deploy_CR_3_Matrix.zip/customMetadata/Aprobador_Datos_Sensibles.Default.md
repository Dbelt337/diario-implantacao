<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <label>Default</label>
    <protected>false</protected>
    <values><field>Es_Default__c</field><value xsi:type="xsd:boolean">true</value></values>
    <values><field>Grupo_Aprobador__c</field><value xsi:type="xsd:string">MDG_Default</value></values>
</CustomMetadata>
