<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
    <label>C105_WEB_CrediQ</label>
    <protected>false</protected>
    <values><field>Sociedad__c</field><value xsi:type="xsd:string">C105</value></values>
    <values><field>Departamento__c</field><value xsi:type="xsd:string">WEB</value></values>
    <values><field>Escenario_Credito__c</field><value xsi:type="xsd:string">CrediQ</value></values>
    <values><field>Grupo_Aprobador__c</field><value xsi:type="xsd:string">MDG_CREDIQ</value></values>
    <values><field>Es_Default__c</field><value xsi:type="xsd:boolean">false</value></values>
</CustomMetadata>
