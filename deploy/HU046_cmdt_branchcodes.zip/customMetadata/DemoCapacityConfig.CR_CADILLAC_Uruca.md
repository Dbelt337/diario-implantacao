<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>CR CADILLAC Uruca</label>
    <protected>false</protected>
    <values><field>Country__c</field><value xsi:type="xsd:string">CR</value></values>
    <values><field>Brand__c</field><value xsi:type="xsd:string">CADILLAC</value></values>
    <values><field>BranchName__c</field><value xsi:type="xsd:string">Uruca</value></values>
    <values><field>MaxDemo__c</field><value xsi:type="xsd:double">3</value></values>
    <values><field>MaxExhibition__c</field><value xsi:type="xsd:double">6</value></values>
    <values><field>BranchCode__c</field><value xsi:type="xsd:string">C0111200</value></values>
</CustomMetadata>