<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>PA CHEVROLET Calle 50 AMW</label>
    <protected>false</protected>
    <values><field>Country__c</field><value xsi:type="xsd:string">PA</value></values>
    <values><field>Brand__c</field><value xsi:type="xsd:string">CHEVROLET</value></values>
    <values><field>BranchName__c</field><value xsi:type="xsd:string">Calle 50 AMW</value></values>
    <values><field>MaxDemo__c</field><value xsi:type="xsd:double">10</value></values>
    <values><field>MaxExhibition__c</field><value xsi:type="xsd:double">10</value></values>
</CustomMetadata>