<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>CR HYUNDAI San Carlos</label>
    <protected>false</protected>
    <values><field>Country__c</field><value xsi:type="xsd:string">CR</value></values>
    <values><field>Brand__c</field><value xsi:type="xsd:string">HYUNDAI</value></values>
    <values><field>BranchName__c</field><value xsi:type="xsd:string">San Carlos</value></values>
    <values><field>MaxDemo__c</field><value xsi:type="xsd:double">15</value></values>
    <values><field>MaxExhibition__c</field><value xsi:type="xsd:double">0</value></values>
</CustomMetadata>